/**
 * figure geometriche
 */
package it.unipr.ferrari.alberto.geometria;

/**
 * @author alberto.ferrari
 * quadrato
 */
public class Quadrato extends Rettangolo {

	public Quadrato(double lato) {
		super(lato, lato);
	}

}
