/**
 * applicazioni di esempio
 */
package it.unipr.ferrari.alberto.applicazioni;

import it.unipr.ferrari.alberto.geometria.Figura;
import it.unipr.ferrari.alberto.geometria.Quadrato;
import it.unipr.ferrari.alberto.geometria.Rettangolo;

/**
 * @author alberto.ferrari
 * esempio utilizzo package
 */
public class EsempioPackage {

	public static void main(String[] args) {
		Figura f = new Rettangolo(10,20);
		System.out.println(f.perimetro());
		Quadrato q = new Quadrato(30);
		System.out.println(q.area());		
	}

}
