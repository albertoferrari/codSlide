/**
 * figure geometriche
 */
package it.unipr.ferrari.alberto.geometria;

/**
 * @author alberto.ferrari
 * rettangolo
 */
public class Rettangolo implements Figura {
	
	/** larghezza del rettangolo */
	private double larghezza;
	/** altezza del rettangolo */	
	private double altezza;
	
	/**
	 * @param larghezza larghezza del rettangolo
	 * @param altezza altezza del rettangolo
	 */
	public Rettangolo(double larghezza, double altezza) {
		super();
		this.larghezza = larghezza;
		this.altezza = altezza;
	}

	/**
	 * @return the larghezza
	 */
	public double getLarghezza() {
		return larghezza;
	}

	/**
	 * @param larghezza the larghezza to set
	 */
	public void setLarghezza(double larghezza) {
		this.larghezza = larghezza;
	}

	/**
	 * @return the altezza
	 */
	public double getAltezza() {
		return altezza;
	}

	/**
	 * @param altezza the altezza to set
	 */
	public void setAltezza(double altezza) {
		this.altezza = altezza;
	}
	
	/**
	 * perimetro del rettangolo
	 * @return misura del perimetro
	 */
	public double perimetro() {
		return 2*(larghezza+altezza);
	}
	
	/**
	 * area del rettangolo
	 * @return misura dell'area
	 */
	public double area() {
		return larghezza*altezza;
	}	
	
}
