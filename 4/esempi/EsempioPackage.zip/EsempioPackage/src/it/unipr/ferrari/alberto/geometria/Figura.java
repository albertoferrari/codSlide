/**
 * figure geometriche
 */
package it.unipr.ferrari.alberto.geometria;

/**
 * @author alberto.ferrari
 * metodi comuni alle figure geometriche
 */
public interface Figura {
	
	/**
	 * perimetro 
	 * @return misura del perimetro
	 */
	public double perimetro();
	
	/**
	 * area
	 * @return misura dell'area
	 */
	public double area();
	
}
