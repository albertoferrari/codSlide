import java.util.Scanner;

/**
 * gioco sudoku
 * @author AF
 *
 */
public class Main {

	/**
	 * visualizza lo stato del gioco
	 * @param m
	 */
	public static void visualizza(int[][] m) {
		for (int[] riga : m) {
			for (int val: riga)
				System.out.print(val+" ");
			System.out.println();
		}
	}
	
	public static void main(String[] args) {
		Sudoku s = new Sudoku("sudoku02.txt");
		Scanner tastiera = new Scanner(System.in);
		int r,c,v;		// riga, colonna, valore
		String scelta;	// inserimento o eliminazione
		if (s.ammissibile()) {
			System.out.println("sudoku ammissibile");
			while (!s.risolto()) {
				visualizza(s.stato());
				String foo = tastiera.nextLine();
				System.out.println("scelta: (i)nserisci o (e)limina ");
				scelta = tastiera.nextLine();
				System.out.println("riga   : "); r=tastiera.nextInt();
				System.out.println("colonna: "); c=tastiera.nextInt();
				if (scelta.charAt(0)=='i') {
					System.out.println("valore : "); v=tastiera.nextInt();
					if (s.inserisci(r,c,v)) {
						System.out.println("*** modifica effettuata ***");
					}
				} 
				else {
					if (s.elimina(r,c)) {
						System.out.println("*** modifica effettuata ***");
					}					
				}
			}
			System.out.println("complimenti sudoku risolto!");
		}
		else
			System.out.println("sudoku non ammissibile");
	}

}
