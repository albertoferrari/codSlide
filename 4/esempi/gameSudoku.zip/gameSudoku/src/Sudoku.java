import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * @author AF
 * Sudoku
 */
public class Sudoku {
	
	/** matrice di gioco celle vuote valore 0 */
	private int[][] matrice;
	
	/** true per i valori predefiniti e non modificabili */
	private boolean[][] predefiniti;

	/**
	 * legge la matrice con valori predefiniti da un file
	 * @param nomeFile nome del file con estensione
	 */
	public Sudoku(String nomeFile) {
		super();
		matrice = new int[9][9];
		predefiniti = new boolean[9][9];
	    try {
	    	File f = new File(nomeFile);
			Scanner sudokuFile = new Scanner(f);
			int r = 0;
			while (sudokuFile.hasNextLine()) {
		        String[] riga = sudokuFile.nextLine().split(",");
		        for (int c=0; c<9; c++) {
		        	int val = Integer.parseInt(riga[c]);
		        	matrice[r][c] = val;
		        	if (val == 0) 
		        		predefiniti[r][c] = false;
		        	else
		        		predefiniti[r][c] = true;
		        }
		        r++;
		     }
			sudokuFile.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * controlla il valore di una cella
	 * @param rc 	riga [0,9]
	 * @param cc 	colonna [0,9]
	 * @param val	valore cella
	 * @return		true se la cella ha un valore ammissibile
	 */
	private boolean corretto(int rc, int cc, int val) {    
		if (val == 0)
			return true;
	    int regc = 3 * (rc/3) + (cc/3);	// regione della cella analizzata
	    for (int r=0;r<9;r++) {
	    	for (int c=0;c<9;c++) {
	    		// se la cella � diversa da quella da analizzare e il valore � uguale
	    		if ((r!=rc || c!=cc) && matrice[r][c]==val) {
	    			int reg = 3 * (r/3) + (c/3);	// regione
	    			if (rc == r || cc == c || regc == reg)
	    				return false;
	    		}
	    	}
	    }
	    return true;
	}	
	
	/**
	 * controlla se la matrice attuale � ammissibile
	 * @return true se matrice ammissibile
	 */
	public boolean ammissibile() {
		for (int r=0; r<9; r++)
			for (int c=0; c<9; c++)
				if (!corretto(r,c,matrice[r][c]))
					return false;
		return true;
	}
	
	/**
	 * controlla se il sudoku � stato risolto
	 * @return true se gioco risolto
	 */
	public boolean risolto() {
		for (int r=0; r<9; r++)
			for (int c=0; c<9; c++)
				if ( (matrice[r][c] == 0) || (!corretto(r,c,matrice[r][c]) ) )
					return false;
		return true;
	}	
	
	/**
	 * Se l'inserimento rispetta i vincoli modifica il valore di una cella
	 * @param r	riga
	 * @param c colonna
	 * @param v valore
	 * @return true se corretto
	 */
	public boolean inserisci(int r, int c, int v) {
		if (this.predefiniti[r][c])
			return false;
		if (corretto(r,c,v)) {
			this.matrice[r][c] = v;
			return true;
		}
		return false;
	}
	
	/**
	 * Elimina, se possibile, il contenuto di una cella
	 * @param r	riga
	 * @param c colonna
	 * @return true se � possibile eliminare il contenuto della cella
	 */
	public boolean elimina(int r, int c) {
		if (this.predefiniti[r][c]) 
			return false;
		this.matrice[r][c]=0;
		return true;
	}
	
	/**
	 * situazione attuale
	 * @return matrice di gioco
	 */
	public int[][] stato() {
		return this.matrice;
	}
}
